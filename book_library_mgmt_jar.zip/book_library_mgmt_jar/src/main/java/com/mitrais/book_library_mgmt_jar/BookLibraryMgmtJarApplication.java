package com.mitrais.book_library_mgmt_jar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookLibraryMgmtJarApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookLibraryMgmtJarApplication.class, args);
	}

}

