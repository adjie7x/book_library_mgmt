package com.mitrais.book_library_mgmt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookLibraryMgmtApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookLibraryMgmtApplication.class, args);
	}

}

